
package gdmsapplication;

import com.databaseCon.DB;
import com.login.folder.LoginFrame;

public class GDMSApplication {

    public static void main(String[] args) {
        
    //Create login frame object

    LoginFrame loginObj = new LoginFrame();
    loginObj.show();
    
    DB.loadConnection();
    
    }
    
}
