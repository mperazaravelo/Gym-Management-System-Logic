/*
  Marla Peraza Ravelo
  CEN 3024C - Software Development 1
  April 17th, 2025
  HomeJFrame.java
  Class that creates the frame containing the Home menu. In this frame the user 
  can perform CRUD operations to interact with the database, like creating, 
  deleting, or updating records 
 */
package com.home;
import com.databaseCon.DB;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

public class HomeJFrame extends javax.swing.JFrame {

    //init components
    public HomeJFrame() {
        initComponents();
        loadTable();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextFieldFilePath = new javax.swing.JTextField();
        jTextFieldName = new javax.swing.JTextField();
        jTextFieldLastName = new javax.swing.JTextField();
        jTextFieldJobTitle = new javax.swing.JTextField();
        jTextFieldAverageWage = new javax.swing.JTextField();
        jDateChooserDateEnrolled = new com.toedter.calendar.JDateChooser();
        jButtonRemove = new javax.swing.JButton();
        jButtonClear = new javax.swing.JButton();
        jButtonUpdate = new javax.swing.JButton();
        jButtonAverageWage = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButtonAddFile1 = new javax.swing.JButton();
        jButtonAddManually1 = new javax.swing.JButton();
        jTextFieldHourlyWage = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 51, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("File Path:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, -1, -1));

        jLabel3.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Name:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 290, -1, -1));

        jLabel4.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Last Name:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 350, -1, -1));

        jLabel5.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Job Title:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 410, -1, -1));

        jLabel6.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Hourly Wage:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 470, -1, -1));

        jLabel7.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Date Enrolled:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 530, -1, -1));

        jLabel8.setFont(new java.awt.Font("Algerian", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Gym Database Management System Home");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 30, -1, -1));

        jTextFieldFilePath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldFilePathActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFieldFilePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 130, 440, -1));

        jTextFieldName.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        jPanel1.add(jTextFieldName, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 290, 440, -1));

        jTextFieldLastName.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        jTextFieldLastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldLastNameActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFieldLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 350, 440, -1));

        jTextFieldJobTitle.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        jPanel1.add(jTextFieldJobTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 410, 440, -1));

        jTextFieldAverageWage.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        jPanel1.add(jTextFieldAverageWage, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 620, 230, -1));
        jPanel1.add(jDateChooserDateEnrolled, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 530, 220, -1));

        jButtonRemove.setBackground(new java.awt.Color(255, 102, 0));
        jButtonRemove.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButtonRemove.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRemove.setText("Remove");
        jButtonRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoveActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonRemove, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 90, -1, -1));

        jButtonClear.setBackground(new java.awt.Color(255, 102, 0));
        jButtonClear.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButtonClear.setForeground(new java.awt.Color(255, 255, 255));
        jButtonClear.setText("Clear");
        jButtonClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonClearActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonClear, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 570, -1, -1));

        jButtonUpdate.setBackground(new java.awt.Color(255, 102, 0));
        jButtonUpdate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButtonUpdate.setForeground(new java.awt.Color(255, 255, 255));
        jButtonUpdate.setText("Update");
        jButtonUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUpdateActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 570, -1, -1));

        jButtonAverageWage.setBackground(new java.awt.Color(255, 102, 0));
        jButtonAverageWage.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButtonAverageWage.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAverageWage.setText("Calculate Average Wage");
        jButtonAverageWage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAverageWageActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonAverageWage, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 620, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Last Name", "Job Title", "Hourly Wage", "Date Enrolled"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 120, 750, 550));

        jButtonAddFile1.setBackground(new java.awt.Color(255, 102, 0));
        jButtonAddFile1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButtonAddFile1.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAddFile1.setText("Add File");
        jButtonAddFile1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddFile1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonAddFile1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 170, -1, -1));

        jButtonAddManually1.setBackground(new java.awt.Color(255, 102, 0));
        jButtonAddManually1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButtonAddManually1.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAddManually1.setText("Add Employee Manually");
        jButtonAddManually1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddManually1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonAddManually1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 570, -1, -1));

        jTextFieldHourlyWage.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        jPanel1.add(jTextFieldHourlyWage, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 470, 440, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1570, 720));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldLastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldLastNameActionPerformed
      
    }//GEN-LAST:event_jTextFieldLastNameActionPerformed
    // Method to calculate Average Wage
    private void jButtonAverageWageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAverageWageActionPerformed
        double sum = 0;
        
        for (int i = 0; i <jTable1.getRowCount(); i++){
            sum = sum + Double.parseDouble(jTable1.getValueAt(i,4).toString());
        }
        double avg = sum / jTable1.getRowCount();
        jTextFieldAverageWage.setText(Double.toString(avg));
    }//GEN-LAST:event_jButtonAverageWageActionPerformed

    //Code for the Clear Button
    private void jButtonClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonClearActionPerformed
        // Clear the text fields
        jTextFieldName.setText("");
        jTextFieldLastName.setText("");
        jTextFieldJobTitle.setText("");
        jTextFieldHourlyWage.setText("");
        jDateChooserDateEnrolled.setCalendar(null);
        jTextFieldAverageWage.setText("");
        jTextFieldFilePath.setText("");
    }//GEN-LAST:event_jButtonClearActionPerformed

    private void jTextFieldFilePathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldFilePathActionPerformed
      
    }//GEN-LAST:event_jTextFieldFilePathActionPerformed
 
    //Code to place the contents of a clicked row on each text fields
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int selectedRow = jTable1.getSelectedRow();
        //if there is no selected row, prompt the user to select a record
        if(selectedRow < 0){
        JOptionPane.showMessageDialog(null, "Please Select any record from table");
            }else{
            //Create DefaultTableModel and get each column
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            String col2 = model.getValueAt(selectedRow,1).toString();
            String col3 = model.getValueAt(selectedRow,2).toString();
            String col4 = model.getValueAt(selectedRow,3).toString();
            String col5 = model.getValueAt(selectedRow,4).toString();
            String col6 = model.getValueAt(selectedRow,5).toString();
        
        //set the text in the columns to the textfields    
        jTextFieldName.setText(col2);
        jTextFieldLastName.setText(col3);
        jTextFieldJobTitle.setText(col4);
        jTextFieldHourlyWage.setText(col5);
        
        //setting text into the DateChooser
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try{
            Date date = sdf.parse(col6);
            jDateChooserDateEnrolled.setDate(date);
        }catch(ParseException e){
            java.util.logging.Logger.getLogger(HomeJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, e);
        }   
    }
       
    }//GEN-LAST:event_jTable1MouseClicked
    //Method to delete/remove a row from the employees table 
    private void jButtonRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoveActionPerformed
        int selectedRow = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int id = (int) model.getValueAt(selectedRow,0);
        
        //if no row is selected, prompt the user to select one
         if (selectedRow < 0 ){
            JOptionPane.showMessageDialog(this, "No row is selected! Please select one row", "Select row", JOptionPane.ERROR_MESSAGE);
        }
        else{
              try{
            //Use query to delete the record      
            String query = "Delete from employees where ID = ?";
            PreparedStatement ps = DB.con.prepareStatement(query);
            ps.setInt(1,id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Record deleted");
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "" + e);
        }
        loadTable();
        }
    }//GEN-LAST:event_jButtonRemoveActionPerformed

    private void jButtonUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonUpdateActionPerformed
        //get table model
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        //get SimpleDataFormat for date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        //get row selected and check if there is a row selected 
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to update.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) model.getValueAt(selectedRow, 0);
        try {
        //get other values from textfields
        String name = jTextFieldName.getText();
        String lastName = jTextFieldLastName.getText();
        String jobTitle = jTextFieldJobTitle.getText();
        String hourlyWageTxt = jTextFieldHourlyWage.getText();
        String date = dateFormat.format(jDateChooserDateEnrolled.getDate());
             
        //make sure that no text field is empty before creating a record
        if (name.isEmpty() ||lastName.isEmpty() || jobTitle.isEmpty()|| hourlyWageTxt.isEmpty() || date.isEmpty()){
                JOptionPane.showMessageDialog(this,"Please Enter all fields", "Try again", JOptionPane.ERROR_MESSAGE);
        }else{
            //create a new variable to change hourly wage to a double and validate input 
            double hourlyWage;
            try {
                hourlyWage = Double.parseDouble(hourlyWageTxt);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number for hourly wage", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            //validate hourly wage (must be between $12.00 and $40.00/hr
            if (hourlyWage < 12.00 || hourlyWage > 40.00){
                JOptionPane.showMessageDialog(this, "Hourly wage must be between $12.00 and $40.00", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }else{
            //use query to update employees
            String query = "update employees set Name = ?, Last_Name = ?, Job_Title = ?, Hourly_Wage = ?, Date_Enrolled = ? where ID = ?";
            PreparedStatement ps = DB.con.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, lastName);
            ps.setString(3, jobTitle);
            ps.setDouble(4, hourlyWage);
            ps.setString(5, date);
            ps.setInt(6, id);
            
            ps.executeUpdate();
            }
        }
        }catch(NullPointerException e){
                JOptionPane.showMessageDialog(null, "Date must not be null. Please enter a date");
        } catch (SQLException ex) {
                Logger.getLogger(HomeJFrame.class.getName()).log(Level.SEVERE, null, ex);             
                    
        }            
        loadTable();
        JOptionPane.showMessageDialog(null, "Record Updated");   
    }//GEN-LAST:event_jButtonUpdateActionPerformed

    //Method to manually add gym employees
    private void jButtonAddManually1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddManually1ActionPerformed
    
        //get SimpleDateFormat for date field
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        
        try { 
        //get values from text fields     
        String name = jTextFieldName.getText();
        String lastName = jTextFieldLastName.getText();
        String jobTitle = jTextFieldJobTitle.getText();
        String hourlyWageTxt = jTextFieldHourlyWage.getText(); //get hourly wage as a String, to be changed later to a double
        String date = dateFormat.format(jDateChooserDateEnrolled.getDate());
        
        //make sure that no text field is empty before creating a record
        if (name.isEmpty() ||lastName.isEmpty() || jobTitle.isEmpty()|| hourlyWageTxt.isEmpty() || date.isEmpty()){
                JOptionPane.showMessageDialog(this,"Please Enter all fields", "Try again", JOptionPane.ERROR_MESSAGE);
        }else{
            //create a new variable to change hourly wage to a double and validate input
            double hourlyWage;
            try {
                hourlyWage = Double.parseDouble(hourlyWageTxt);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number for hourly wage", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            //validate hourly wage (must be between $12.00 and $40.00/hr
            if (hourlyWage < 12.00 || hourlyWage > 40.00){
                JOptionPane.showMessageDialog(this, "Hourly wage must be between $12.00 and $40.00", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }else{
                //insert values into table employees using queries
                String query = "insert into employees values(NULL, ?, ?, ?, ?, ?)";
                PreparedStatement ps = DB.con.prepareStatement(query);
                ps.setString(1, name);
                ps.setString(2, lastName);
                ps.setString(3, jobTitle);
                ps.setDouble(4, hourlyWage);
                ps.setString(5, date);
           
                ps.executeUpdate();
                loadTable(); 
                JOptionPane.showMessageDialog(null, "A record has been added");
            }
        }   
       }catch(NullPointerException e){
           JOptionPane.showMessageDialog(null, "Date must not be null. Please enter a date");
       }catch (SQLException ex) { 
            Logger.getLogger(HomeJFrame.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }//GEN-LAST:event_jButtonAddManually1ActionPerformed

    //method to add new records to employees table through a file
    private void jButtonAddFile1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddFile1ActionPerformed
        String filePath = jTextFieldFilePath.getText().trim();
    //check if path is empty
    if (filePath.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a file path.", "Missing File Path", JOptionPane.WARNING_MESSAGE);
        return;
    }

    File file = new File(filePath);
    
    //check if the path is correct
    if (!file.exists()) {
        JOptionPane.showMessageDialog(this, "File not found. Please check the path and try again.", "File Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try (FileReader fr = new FileReader(file); BufferedReader br = new BufferedReader(fr)) {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        Object[] lines = br.lines().toArray();

        //Take each line of the file and split it in smaller chunks after the commas, which are the values added to the database
        for (int i = 0; i < lines.length; i++) {
            String[] row = lines[i].toString().split(",");
            model.addRow(row);

            String query = "insert into employees values(NULL, ?, ?, ?, ?, ?)";
            try (PreparedStatement ps = DB.con.prepareStatement(query)) {
                ps.setString(1, row[0]);
                ps.setString(2, row[1]);
                ps.setString(3, row[2]);
                ps.setDouble(4, Double.parseDouble(row[3]));
                ps.setString(5, row[4]);
                ps.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(HomeJFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        loadTable();
        JOptionPane.showMessageDialog(this, "File imported successfully.");

    } catch (IOException ex) {
        Logger.getLogger(HomeJFrame.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(this, "An error occurred while reading the file.", "Read Error", JOptionPane.ERROR_MESSAGE);
    }
         

    }//GEN-LAST:event_jButtonAddFile1ActionPerformed
    
    //method to load data from a list into a DefaultTableModel
    public void loadAllDataIntoTable(List<GymEmployee> list){
       DefaultTableModel dtm = (DefaultTableModel) jTable1.getModel();
       dtm.setRowCount(0);
       
       for (GymEmployee bean: list) {
           Vector v = new Vector();
           v.add(bean.getId());
           v.add(bean.getFirstName());
           v.add(bean.getLastName());
           v.add(bean.getJobTitle());
           v.add(bean.getHourlyWage());
           v.add(bean.getDateEnrolled());
           
           dtm.addRow(v);
           
                  
       }
    }
    
    //method to load Data from database into GymEmployee object
    public List<GymEmployee> loadData(){
        List<GymEmployee> list = new ArrayList<>();
        try{
          String query = "select * from employees";
          PreparedStatement ps = DB.con.prepareStatement(query);
          ResultSet rs = ps.executeQuery();
          while (rs.next()){
              int id = rs.getInt("ID");
              String firstName = rs.getString("Name");
              String lastName = rs.getString("Last_Name");
              String jobTitle = rs.getString("Job_Title");
              double hourlyWage = rs.getDouble("Hourly_Wage");
              String dateEnrolled = rs.getString("Date_Enrolled");
              
              GymEmployee bean = new GymEmployee(id, firstName, lastName, jobTitle, hourlyWage, dateEnrolled);
              list.add(bean);
             
     
          }
         
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, ""+ e);
        }
        return list;
    }
    //method to load the data into jtable
    public void loadTable(){
        List list = loadData();
        loadAllDataIntoTable(list);
        
    }
    
    //main method
    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomeJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAddFile1;
    private javax.swing.JButton jButtonAddManually1;
    private javax.swing.JButton jButtonAverageWage;
    private javax.swing.JButton jButtonClear;
    private javax.swing.JButton jButtonRemove;
    private javax.swing.JButton jButtonUpdate;
    private com.toedter.calendar.JDateChooser jDateChooserDateEnrolled;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextFieldAverageWage;
    private javax.swing.JTextField jTextFieldFilePath;
    private javax.swing.JTextField jTextFieldHourlyWage;
    private javax.swing.JTextField jTextFieldJobTitle;
    private javax.swing.JTextField jTextFieldLastName;
    private javax.swing.JTextField jTextFieldName;
    // End of variables declaration//GEN-END:variables
}
