/*
  Marla Peraza Ravelo
  CEN 3024C - Software Development 1
  April 17th, 2025
  GymEmployee.java
  Class that creates a GymEmployee object containing the fields inside the 
  "employees" table in the database. It represents a gym employee 
 */
package com.home;

public class GymEmployee {
    
    //Attributes
    private int id;
    private String firstName;
    private String lastName;
    private String jobTitle;
    private double hourlyWage;
    private String dateEnrolled;

    //Constructor
    public GymEmployee(int id, String firstName, String lastName, String jobTitle, double hourlyWage, String dateEnrolled) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.jobTitle = jobTitle;
        this.hourlyWage = hourlyWage;
        this.dateEnrolled = dateEnrolled;
    }

    //getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public void setHourlyWage(double hourlyWage) {
        this.hourlyWage = hourlyWage;
    }

    public String getDateEnrolled() {
        return dateEnrolled;
    }

    public void setDateEnrolled(String dateEnrolled) {
        this.dateEnrolled = dateEnrolled;
    }
    
     
}
