/*
  Marla Peraza Ravelo
  CEN 3024C - Software Development 1
  April 17th, 2025
  DB.java
  This class supplies the connection to the database
 */
package com.databaseCon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class DB {
    public static Connection con = null;
    
    public static void loadConnection(){
    try {
        //Create an url
        Class.forName("org.sqlite.JDBC");
        String url = "jdbc:sqlite:C:\\sqlite\\GDMSys.db";
        
        //Connect with DriverManager
        try {
            con = DriverManager.getConnection(url);
            
            if (con !=null){
                JOptionPane.showMessageDialog(null,"database has been successfully connected to" );
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error in Database Loading" +e);
        }
        
        
    }catch(ClassNotFoundException ex){
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE,null, ex);
    }
    
    
}
}
