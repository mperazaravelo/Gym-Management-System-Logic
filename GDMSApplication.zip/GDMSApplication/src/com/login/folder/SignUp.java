/*
  Marla Peraza Ravelo
  CEN 3024C - Software Development 1
  April 17th, 2025
  SignUp.java
  Class that creates a SignUp object containing the fields inside the "signup" 
  table in the database. It represents all the users that can access the database 
 */
package com.login.folder;

public class SignUp {
 
    //Attributes
    private String fullName;
    private String userName;
    private String password;

    //Constructor
    public SignUp(String fullName, String userName, String password) {
        this.fullName = fullName;
        this.userName = userName;
        this.password = password;
    }

    //Getters and setters
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
}
