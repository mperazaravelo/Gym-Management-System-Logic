/*
  Marla Peraza Ravelo
  CEN 3024C - Software Development 1
  April 17th, 2025
  Bal.java
  This class contains additional methods (insertDataSignup and CheckLogin) that 
  are used in other classes for convenience. 
 */

package com.login.folder;

import com.databaseCon.DB;
import com.login.folder.SignUp;
import java.sql.Statement;
import javax.swing.JOptionPane;
 import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Bal {
    
    public void insertDataSignup(SignUp signObj){
        try{
        //create query for inserting signup data
        String query = "INSERT INTO signup VALUES(null,?,?,?)";
        PreparedStatement ps = DB.con.prepareStatement(query);
        ps.setString(1, signObj.getFullName());
        ps.setString(2, signObj.getUserName());
        ps.setString(3, signObj.getPassword());
        
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "Signed up sucesfully, now go login");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,""+ e);
        }
        
    }
    
    //Create method to check data from signuo table
public boolean checkLogin(String username, String pass){
boolean b = false;    
try{
    //create query
String query = "select Username, Password from signup where Username = '"+username+"' and Password = '"+pass+"'";
        Statement st = DB.con.createStatement();
        ResultSet rs = st.executeQuery(query);
        if (rs.next()){
            b = true;
}else{
            JOptionPane.showMessageDialog(null, "Invalid username or password. Try Again");
        }

}catch(Exception e){
JOptionPane.showMessageDialog(null,""+ e);
}

return b;
}
}


